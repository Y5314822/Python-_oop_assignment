# Assignment 1 & 2 - Python OOP
# Author: Yusuf Ibrahim

# -------------------------------
# CLASS DESIGN: Superhero Example
# -------------------------------

class Superhero:
    def __init__(self, name, power, strength):
        self.name = name
        self.power = power
        self.__strength = strength  # Encapsulation

    def show_info(self):
        print(f"🦸 Superhero: {self.name} | Power: {self.power} | Strength: {self.__strength}")

    def boost_strength(self, amount):
        self.__strength += amount
        print(f"{self.name}'s strength increased to {self.__strength}!")

# Subclass demonstrating inheritance
class FlyingHero(Superhero):
    def __init__(self, name, power, strength, flight_speed):
        super().__init__(name, power, strength)
        self.flight_speed = flight_speed

    def show_info(self):
        print(f"🦅 Flying Hero: {self.name} | Power: {self.power} | Flight Speed: {self.flight_speed} km/h")

# -------------------------------
# ACTIVITY 2: Polymorphism Challenge 🎭
# -------------------------------

class Animal:
    def move(self):
        print("The animal moves in some way.")

class Dog(Animal):
    def move(self):
        print("🐕 The dog runs on four legs.")

class Bird(Animal):
    def move(self):
        print("🐦 The bird flies in the sky.")

class Fish(Animal):
    def move(self):
        print("🐠 The fish swims in the water.")

# -------------------------------
# MAIN PROGRAM
# -------------------------------
if __name__ == "__main__":
    print("\n--- Superhero Class Demo ---")
    hero1 = Superhero("Thor", "Lightning", 90)
    hero1.show_info()
    hero1.boost_strength(10)

    print("\n--- FlyingHero Subclass Demo ---")
    hero2 = FlyingHero("Iron Man", "Technology", 85, 300)
    hero2.show_info()

    print("\n--- Polymorphism Challenge ---")
    animals = [Dog(), Bird(), Fish()]
    for a in animals:
        a.move()
