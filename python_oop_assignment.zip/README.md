# Python OOP Assignment

## 📘 Assignment 1: Design Your Own Class
This project demonstrates Object-Oriented Programming (OOP) concepts in Python including:
- Classes and Objects
- Inheritance
- Encapsulation
- Polymorphism

### Example: Superhero Class
The project defines a `Superhero` class with private attributes and a subclass `FlyingHero` to demonstrate inheritance and encapsulation.

## 🎭 Activity 2: Polymorphism Challenge
Different animal classes (`Dog`, `Bird`, `Fish`) override the same method `move()` to show polymorphism in action.

## 🚀 How to Run
Run the following command in your terminal:
```bash
python oop_assignment.py
```

## 👨‍💻 Author
**Yusuf Ibrahim**
